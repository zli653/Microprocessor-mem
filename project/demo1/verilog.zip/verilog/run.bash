wsrun.pl proc_hier proc_hier_bench.v *.v
